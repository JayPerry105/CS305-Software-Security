package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController{  
    @RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException{
    	String data = "Hello Dr. North! - Jacob Perry";
    	
    	MessageDigest digest = MessageDigest.getInstance("SHA-256");
    	
    	byte[] hashBytes = digest.digest(data.getBytes());
    	
    	String checksum = bytesToHex(hashBytes); 	  
   	
       
        return "<p>data:"+ data + "</p><p>SHA-256: CheckSum Value: " + checksum + "</p>";
    }
    
    public static String bytesToHex(byte[] bytes) {
    	StringBuilder hexString = new StringBuilder();
    	for (byte b : bytes) {
    		String hex = Integer.toHexString(b);
    		if (hex.length() == 1) {
    			hexString.append('0');
    		}
    		hexString.append(hex);
    	}
    	return hexString.toString();
    }
  
}
